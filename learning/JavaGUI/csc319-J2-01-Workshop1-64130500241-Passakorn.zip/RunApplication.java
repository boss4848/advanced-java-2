public class RunApplication {
    public static void main(String[] args) {
        new ApplicationWindow();
    }
}
